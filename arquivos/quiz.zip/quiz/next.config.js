module.exports = {
  reactStrictMode: true,
}
